import { Router, Request, Response } from 'express';
import { supabaseDb } from '../services/supabaseDb.ts';
import { requireAuth } from '../middleware/auth.ts';

export const usersRouter = Router();

// GET /users - list all student profiles with computed stats
usersRouter.get('/', async (_req: Request, res: Response) => {
  try {
    const usersWithStats = await supabaseDb.getUsers();
    return res.status(200).json({
      success: true,
      data: usersWithStats,
      message: 'Student profiles retrieved successfully.'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: error.message || 'Failed to fetch users.' }
    });
  }
});

// GET /users/:id - get single user profile with computed stats
usersRouter.get('/:id', async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_ID', message: 'User ID must be an integer.' }
      });
    }

    const profile = await supabaseDb.getUserById(id);
    if (!profile) {
      return res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: `User with ID ${id} not found.` }
      });
    }

    return res.status(200).json({
      success: true,
      data: profile,
      message: 'User profile retrieved successfully.'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: error.message || 'Failed to fetch user profile.' }
    });
  }
});

// PATCH /users/:id - edit own allowed profile fields
usersRouter.patch('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_ID', message: 'User ID must be an integer.' }
      });
    }

    if (req.authUserId !== id) {
      return res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: 'You can only edit your own student profile.' }
      });
    }

    const { bio, skills, major, semester } = req.body;

    if (bio !== undefined && (typeof bio !== 'string' || bio.trim().length === 0)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_BIO', message: 'Bio must be a non-empty string.' }
      });
    }

    if (skills !== undefined && !Array.isArray(skills)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_SKILLS', message: 'Skills must be an array of strings.' }
      });
    }

    if (major !== undefined && (typeof major !== 'string' || major.trim().length === 0)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_MAJOR', message: 'Major must be a non-empty string.' }
      });
    }

    if (semester !== undefined) {
      const sem = Number(semester);
      if (isNaN(sem) || sem < 1 || sem > 16) {
        return res.status(400).json({
          success: false,
          error: { code: 'INVALID_SEMESTER', message: 'Semester must be a valid number between 1 and 16.' }
        });
      }
    }

    const updatedUser = await supabaseDb.updateUser(id, {
      bio,
      skills,
      major,
      semester
    });

    return res.status(200).json({
      success: true,
      data: updatedUser,
      message: 'Profile updated successfully.'
    });
  } catch (error: any) {
    return res.status(400).json({
      success: false,
      error: { code: 'VALIDATION_ERROR', message: error.message || 'Failed to update profile.' }
    });
  }
});
