import { Router, Request, Response } from 'express';
import { supabase, isSupabaseServerConfigured } from '../supabase.ts';
import { supabaseDb } from '../services/supabaseDb.ts';
import { localEngine } from '../services/localEngine.ts';
import { requireAuth } from '../middleware/auth.ts';

export const authRouter = Router();

// POST /auth/signup
authRouter.post('/signup', async (req: Request, res: Response) => {
  try {
    const { email, password, name, major, semester, bio, skills } = req.body;

    if (!email || typeof email !== 'string' || !email.includes('@')) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_EMAIL', message: 'A valid university email address is required.' }
      });
    }

    if (!password || typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({
        success: false,
        error: { code: 'WEAK_PASSWORD', message: 'Password must be at least 6 characters long.' }
      });
    }

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_NAME', message: 'Full name is required (minimum 2 characters).' }
      });
    }

    const semNum = Number(semester || 1);
    if (isNaN(semNum) || semNum < 1 || semNum > 16) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_SEMESTER', message: 'Semester must be between 1 and 16.' }
      });
    }

    const cleanEmail = email.trim().toLowerCase();

    // 1. Live Supabase Cloud
    if (isSupabaseServerConfigured()) {
      const client = supabase.client;
      const { data: authData, error: authErr } = await client.auth.admin.createUser({
        email: cleanEmail,
        password,
        email_confirm: true,
        user_metadata: {
          name: name.trim(),
          major: (major || 'Undeclared').trim(),
          semester: semNum,
          bio: (bio || 'Student member at CampusConnect.').trim(),
          skills: Array.isArray(skills) ? skills.map((s) => String(s).trim()).filter(Boolean) : []
        }
      });

      if (authErr) {
        return res.status(400).json({
          success: false,
          error: { code: 'SIGNUP_FAILED', message: authErr.message }
        });
      }

      const profile = await supabaseDb.linkOrRegisterAuthProfile(authData.user!);
      const { data: signinData } = await client.auth.signInWithPassword({
        email: cleanEmail,
        password
      });

      const token = signinData?.session?.access_token || '';

      return res.status(201).json({
        success: true,
        data: { token, user: profile },
        message: 'Student account created and authenticated via Supabase.'
      });
    }

    // 2. Preview Engine
    const profile = await localEngine.register({
      email: cleanEmail,
      password,
      name: name.trim(),
      major: (major || 'Undeclared').trim(),
      semester: semNum,
      bio: (bio || 'Student member at CampusConnect.').trim(),
      skills: Array.isArray(skills) ? skills.map((s) => String(s).trim()).filter(Boolean) : []
    });

    const token = localEngine.createSessionToken(profile);

    return res.status(201).json({
      success: true,
      data: { token, user: profile },
      message: 'Student account created and authenticated.'
    });
  } catch (err: any) {
    const status = err.message.includes('already exists') ? 409 : 400;
    return res.status(status).json({
      success: false,
      error: { code: 'REGISTRATION_ERROR', message: err.message || 'Registration failed.' }
    });
  }
});

// POST /auth/login
authRouter.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: { code: 'MISSING_CREDENTIALS', message: 'Email and password are required.' }
      });
    }

    const cleanEmail = email.trim().toLowerCase();

    // 1. Live Supabase Cloud
    if (isSupabaseServerConfigured()) {
      const client = supabase.client;
      const { data, error } = await client.auth.signInWithPassword({
        email: cleanEmail,
        password
      });

      if (error || !data.session || !data.user) {
        return res.status(401).json({
          success: false,
          error: { code: 'INVALID_CREDENTIALS', message: error?.message || 'Invalid email or password.' }
        });
      }

      const profile = await supabaseDb.linkOrRegisterAuthProfile(data.user);

      return res.status(200).json({
        success: true,
        data: {
          token: data.session.access_token,
          user: profile
        },
        message: 'Logged in successfully via Supabase Auth.'
      });
    }

    // 2. Preview Engine
    const user = await localEngine.authenticate(cleanEmail, password);
    const token = localEngine.createSessionToken(user);

    return res.status(200).json({
      success: true,
      data: {
        token,
        user
      },
      message: 'Logged in successfully.'
    });
  } catch (err: any) {
    return res.status(401).json({
      success: false,
      error: { code: 'INVALID_CREDENTIALS', message: err.message || 'Login failed.' }
    });
  }
});

// GET /auth/me
authRouter.get('/me', requireAuth, async (req: Request, res: Response) => {
  return res.status(200).json({
    success: true,
    data: req.authUser,
    message: 'Active student session retrieved.'
  });
});

// POST /auth/logout
authRouter.post('/logout', (_req: Request, res: Response) => {
  return res.status(200).json({
    success: true,
    message: 'Logged out successfully.'
  });
});
