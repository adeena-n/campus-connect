import { Router, Request, Response } from 'express';
import { runSupabaseSeed } from '../seed.ts';
import { isSupabaseServerConfigured } from '../supabase.ts';

export const seedRouter = Router();

seedRouter.post('/reset', async (_req: Request, res: Response) => {
  if (!isSupabaseServerConfigured()) {
    return res.status(503).json({
      success: false,
      error: {
        code: 'SUPABASE_NOT_CONFIGURED',
        message: 'Supabase is not configured. Please define SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.'
      }
    });
  }

  try {
    const stats = await runSupabaseSeed();
    return res.status(200).json({
      success: true,
      data: {
        users_count: stats.usersCount,
        gigs_count: stats.gigsCount,
        applications_count: stats.appsCount,
        reviews_count: stats.reviewsCount,
        evaluators_count: stats.evaluatorsCount
      },
      message: 'Supabase database reset and seeded successfully.'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: { code: 'RESET_FAILED', message: error.message || 'Failed to seed Supabase database.' }
    });
  }
});
