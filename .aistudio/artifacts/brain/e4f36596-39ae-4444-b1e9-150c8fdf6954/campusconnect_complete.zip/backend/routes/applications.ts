import { Router, Request, Response } from 'express';
import { supabaseDb } from '../services/supabaseDb.ts';
import { requireAuth } from '../middleware/auth.ts';

export const applicationsRouter = Router();

// GET /applications?gig_id=101 or ?mine=true
applicationsRouter.get('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const { gig_id, mine } = req.query;

    if (mine === 'true') {
      const myApps = await supabaseDb.getApplicationsByUser(req.authUserId!);
      return res.status(200).json({
        success: true,
        data: myApps,
        message: 'My applications retrieved successfully.'
      });
    }

    if (gig_id) {
      const gId = parseInt(gig_id as string, 10);
      if (isNaN(gId)) {
        return res.status(400).json({
          success: false,
          error: { code: 'INVALID_GIG_ID', message: 'gig_id must be an integer.' }
        });
      }

      const apps = await supabaseDb.getApplicationsByGig(gId, req.authUserId!);
      return res.status(200).json({
        success: true,
        data: apps,
        message: 'Gig applications retrieved successfully.'
      });
    }

    return res.status(400).json({
      success: false,
      error: { code: 'MISSING_PARAM', message: 'Specify either ?gig_id=<id> or ?mine=true.' }
    });
  } catch (error: any) {
    const status = error.message.includes('Forbidden')
      ? 403
      : error.message.includes('not found')
      ? 404
      : 500;

    return res.status(status).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: error.message || 'Failed to fetch applications.' }
    });
  }
});

// POST /applications - submit application
applicationsRouter.post('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const { gig_id, message } = req.body;
    const gId = parseInt(gig_id, 10);
    if (isNaN(gId)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_GIG_ID', message: 'gig_id must be an integer.' }
      });
    }

    if (!message || typeof message !== 'string' || message.trim().length < 10 || message.trim().length > 500) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_MESSAGE',
          message: 'Application message is required and must be between 10 and 500 characters.'
        }
      });
    }

    const application = await supabaseDb.createApplication({
      gig_id: gId,
      applicant_id: req.authUserId!,
      message: message.trim()
    });

    return res.status(201).json({
      success: true,
      data: application,
      message: 'Application submitted successfully.'
    });
  } catch (error: any) {
    const status = error.message.includes('Duplicate')
      ? 409
      : error.message.includes('Forbidden')
      ? 400
      : error.message.includes('not found')
      ? 404
      : 400;

    return res.status(status).json({
      success: false,
      error: { code: 'APPLICATION_ERROR', message: error.message || 'Failed to submit application.' }
    });
  }
});

// PATCH /applications/:id - owner accepts or rejects application
applicationsRouter.patch('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const appId = parseInt(req.params.id, 10);
    if (isNaN(appId)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_ID', message: 'Application ID must be an integer.' }
      });
    }

    const { action } = req.body;
    if (action !== 'accept' && action !== 'reject') {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_ACTION', message: 'Action must be either "accept" or "reject".' }
      });
    }

    const result = await supabaseDb.updateApplicationAction(appId, req.authUserId!, action);

    return res.status(200).json({
      success: true,
      data: result,
      message:
        action === 'accept'
          ? `Accepted application #${appId}. Gig is now In Progress and remaining pending applications were rejected.`
          : `Application #${appId} rejected.`
    });
  } catch (error: any) {
    const status = error.message.includes('Forbidden')
      ? 403
      : error.message.includes('not found')
      ? 404
      : 400;

    return res.status(status).json({
      success: false,
      error: { code: 'ACTION_FAILED', message: error.message || 'Failed to update application.' }
    });
  }
});
