import { Router, Request, Response } from 'express';
import { supabaseDb } from '../services/supabaseDb.ts';
import { requireAuth, optionalAuth } from '../middleware/auth.ts';
import { GigType, GigCategory, PaymentType } from '../types.ts';

export const gigsRouter = Router();

const VALID_CATEGORIES: GigCategory[] = ['Programming', 'Design', 'Writing', 'Tutoring'];
const VALID_TYPES: GigType[] = ['Offering', 'Requesting'];
const VALID_PAYMENT_TYPES: PaymentType[] = ['Paid', 'SkillSwap', 'Free'];

// GET /gigs - search and combined filters
gigsRouter.get('/', optionalAuth, async (req: Request, res: Response) => {
  try {
    const { category, type, payment_type, min_budget, max_budget, q, status, user_id } = req.query;

    const minB = min_budget ? parseFloat(min_budget as string) : undefined;
    const maxB = max_budget ? parseFloat(max_budget as string) : undefined;
    const uId = user_id ? parseInt(user_id as string, 10) : undefined;

    const gigs = await supabaseDb.getGigs({
      category: typeof category === 'string' ? category : undefined,
      type: typeof type === 'string' ? type : undefined,
      payment_type: typeof payment_type === 'string' ? payment_type : undefined,
      status: typeof status === 'string' ? status : undefined,
      user_id: !isNaN(uId!) ? uId : undefined,
      min_budget: !isNaN(minB!) ? minB : undefined,
      max_budget: !isNaN(maxB!) ? maxB : undefined,
      q: typeof q === 'string' ? q : undefined
    });

    return res.status(200).json({
      success: true,
      data: gigs,
      message: 'Gigs retrieved successfully.'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: error.message || 'Failed to search gigs.' }
    });
  }
});

// GET /gigs/:id - get single gig detail
gigsRouter.get('/:id', optionalAuth, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_ID', message: 'Gig ID must be an integer.' }
      });
    }

    const gig = await supabaseDb.getGigById(id);
    if (!gig) {
      return res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: `Gig with ID ${id} not found.` }
      });
    }

    return res.status(200).json({
      success: true,
      data: gig,
      message: 'Gig detail retrieved successfully.'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: error.message || 'Failed to retrieve gig detail.' }
    });
  }
});

// POST /gigs - create new gig
gigsRouter.post('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const { title, description, type, category, payment_type, budget, deadline } = req.body;

    if (!title || typeof title !== 'string' || title.trim().length < 5 || title.trim().length > 100) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_TITLE', message: 'Title is required and must be between 5 and 100 characters.' }
      });
    }

    if (!description || typeof description !== 'string' || description.trim().length < 20 || description.trim().length > 2000) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_DESCRIPTION', message: 'Description is required and must be between 20 and 2000 characters.' }
      });
    }

    if (!VALID_TYPES.includes(type)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_TYPE', message: `Type must be one of: ${VALID_TYPES.join(', ')}.` }
      });
    }

    if (!VALID_CATEGORIES.includes(category)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_CATEGORY', message: `Category must be one of: ${VALID_CATEGORIES.join(', ')}.` }
      });
    }

    if (!VALID_PAYMENT_TYPES.includes(payment_type)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_PAYMENT_TYPE', message: `Payment type must be one of: ${VALID_PAYMENT_TYPES.join(', ')}.` }
      });
    }

    let finalBudget: number | null = null;
    if (payment_type === 'Paid') {
      const numBudget = Number(budget);
      if (budget === undefined || budget === null || isNaN(numBudget) || numBudget <= 0) {
        return res.status(400).json({
          success: false,
          error: { code: 'INVALID_BUDGET', message: 'Paid gigs require a positive budget amount.' }
        });
      }
      finalBudget = numBudget;
    } else {
      if (budget !== undefined && budget !== null && budget !== '') {
        return res.status(400).json({
          success: false,
          error: { code: 'INVALID_BUDGET', message: 'Budget must be null for SkillSwap and Free gigs.' }
        });
      }
      finalBudget = null;
    }

    if (!deadline) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_DEADLINE', message: 'Deadline is required.' }
      });
    }

    const deadlineDate = new Date(deadline);
    if (isNaN(deadlineDate.getTime())) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_DEADLINE', message: 'Deadline must be a valid ISO date/time string.' }
      });
    }

    if (deadlineDate.getTime() <= Date.now()) {
      return res.status(400).json({
        success: false,
        error: { code: 'PAST_DEADLINE', message: 'Deadline must be a future date and time.' }
      });
    }

    const createdGig = await supabaseDb.createGig({
      user_id: req.authUserId!,
      title: title.trim(),
      description: description.trim(),
      type,
      category,
      payment_type,
      budget: finalBudget,
      deadline: deadlineDate.toISOString()
    });

    return res.status(201).json({
      success: true,
      data: createdGig,
      message: 'Gig created successfully.'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: error.message || 'Failed to create gig.' }
    });
  }
});

// PATCH /gigs/:id - allowed owner edit or status action
gigsRouter.patch('/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_ID', message: 'Gig ID must be an integer.' }
      });
    }

    const { action } = req.body;
    if (action !== 'complete' && action !== 'cancel') {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_ACTION', message: `Invalid action "${action}". Allowed: "complete", "cancel".` }
      });
    }

    const updatedGig = await supabaseDb.updateGigAction(id, req.authUserId!, action);

    return res.status(200).json({
      success: true,
      data: updatedGig,
      message: `Gig ${action === 'complete' ? 'marked as Completed' : 'cancelled'} successfully.`
    });
  } catch (error: any) {
    const status = error.message.includes('Forbidden')
      ? 403
      : error.message.includes('not found')
      ? 404
      : 400;

    return res.status(status).json({
      success: false,
      error: { code: 'STATUS_UPDATE_ERROR', message: error.message || 'Failed to update gig.' }
    });
  }
});
