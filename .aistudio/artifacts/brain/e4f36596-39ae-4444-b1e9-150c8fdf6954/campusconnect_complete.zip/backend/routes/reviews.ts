import { Router, Request, Response } from 'express';
import { supabaseDb } from '../services/supabaseDb.ts';
import { requireAuth, optionalAuth } from '../middleware/auth.ts';

export const reviewsRouter = Router();

// GET /reviews?reviewee_id=2 or ?gig_id=105
reviewsRouter.get('/', optionalAuth, async (req: Request, res: Response) => {
  try {
    const { reviewee_id, gig_id } = req.query;
    const rId = reviewee_id ? parseInt(reviewee_id as string, 10) : undefined;
    const gId = gig_id ? parseInt(gig_id as string, 10) : undefined;

    const reviews = await supabaseDb.getReviews({
      reviewee_id: !isNaN(rId!) ? rId : undefined,
      gig_id: !isNaN(gId!) ? gId : undefined
    });

    return res.status(200).json({
      success: true,
      data: reviews,
      message: 'Reviews retrieved successfully.'
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: error.message || 'Failed to fetch reviews.' }
    });
  }
});

// POST /reviews - submit mutual review
reviewsRouter.post('/', requireAuth, async (req: Request, res: Response) => {
  try {
    const { gig_id, reviewee_id, rating, comment } = req.body;
    const gId = parseInt(gig_id, 10);
    const rId = parseInt(reviewee_id, 10);
    const numRating = Number(rating);

    if (isNaN(gId)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_GIG_ID', message: 'gig_id must be an integer.' }
      });
    }

    if (isNaN(rId)) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_REVIEWEE_ID', message: 'reviewee_id must be an integer.' }
      });
    }

    if (!Number.isInteger(numRating) || numRating < 1 || numRating > 5) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_RATING', message: 'Rating must be an integer between 1 and 5.' }
      });
    }

    if (!comment || typeof comment !== 'string' || comment.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: { code: 'INVALID_COMMENT', message: 'Comment is required.' }
      });
    }

    const reviewerId = req.authUserId!;

    if (reviewerId === rId) {
      return res.status(400).json({
        success: false,
        error: { code: 'SELF_REVIEW', message: 'You cannot submit a review for yourself.' }
      });
    }

    const result = await supabaseDb.createReview({
      gig_id: gId,
      reviewer_id: reviewerId,
      reviewee_id: rId,
      rating: numRating,
      comment: comment.trim()
    });

    return res.status(201).json({
      success: true,
      data: result,
      message: 'Review submitted successfully.'
    });
  } catch (error: any) {
    const status = error.message.includes('Duplicate')
      ? 409
      : error.message.includes('Forbidden')
      ? 403
      : error.message.includes('not found')
      ? 404
      : 400;

    return res.status(status).json({
      success: false,
      error: { code: 'REVIEW_ERROR', message: error.message || 'Failed to submit review.' }
    });
  }
});
