import dotenv from 'dotenv';
import { supabase, isSupabaseServerConfigured } from './supabase.ts';
import { getSeedData } from './seedData.ts';

dotenv.config();

export async function runSupabaseSeed(): Promise<{
  usersCount: number;
  gigsCount: number;
  appsCount: number;
  reviewsCount: number;
  evaluatorsCount: number;
}> {
  if (!isSupabaseServerConfigured()) {
    throw new Error(
      'Cannot seed database: Supabase is not configured. Please define SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env.'
    );
  }

  const client = supabase.client;
  const seed = getSeedData(true);

  console.log('🌱 Starting Supabase PostgreSQL seeding...');

  // 1. Seed Student Profiles (Users)
  console.log(`  Inserting ${seed.users.length} student profiles...`);
  for (const u of seed.users) {
    const { error } = await client.from('users').upsert(
      {
        id: u.id,
        email: u.email,
        name: u.name,
        major: u.major,
        semester: u.semester,
        bio: u.bio,
        skills: u.skills
      },
      { onConflict: 'id' }
    );
    if (error) {
      console.error(`  Error inserting student ${u.name}:`, error.message);
    }
  }

  // 2. Seed Gigs (temporarily set accepted_applicant_id to null to satisfy foreign keys)
  console.log(`  Inserting ${seed.gigs.length} gigs...`);
  for (const g of seed.gigs) {
    const { error } = await client.from('gigs').upsert(
      {
        id: g.id,
        user_id: g.user_id,
        title: g.title,
        description: g.description,
        type: g.type,
        category: g.category,
        payment_type: g.payment_type,
        budget: g.budget,
        deadline: g.deadline,
        status: g.status,
        accepted_applicant_id: null,
        created_at: g.created_at
      },
      { onConflict: 'id' }
    );
    if (error) {
      console.error(`  Error inserting gig #${g.id}:`, error.message);
    }
  }

  // 3. Seed Applications
  console.log(`  Inserting ${seed.applications.length} applications...`);
  for (const a of seed.applications) {
    const { error } = await client.from('applications').upsert(
      {
        id: a.id,
        gig_id: a.gig_id,
        applicant_id: a.applicant_id,
        message: a.message,
        status: a.status,
        created_at: a.created_at
      },
      { onConflict: 'id' }
    );
    if (error) {
      console.error(`  Error inserting application #${a.id}:`, error.message);
    }
  }

  // 4. Update accepted_applicant_id on In Progress & Completed Gigs
  console.log('  Linking accepted applicants on In Progress and Completed gigs...');
  for (const g of seed.gigs) {
    if (g.accepted_applicant_id) {
      const { error } = await client
        .from('gigs')
        .update({ accepted_applicant_id: g.accepted_applicant_id })
        .eq('id', g.id);
      if (error) {
        console.error(`  Error linking accepted applicant for gig #${g.id}:`, error.message);
      }
    }
  }

  // 5. Seed Reviews
  console.log(`  Inserting ${seed.reviews.length} peer reviews...`);
  for (const r of seed.reviews) {
    const { error } = await client.from('reviews').upsert(
      {
        id: r.id,
        gig_id: r.gig_id,
        reviewer_id: r.reviewer_id,
        reviewee_id: r.reviewee_id,
        rating: r.rating,
        comment: r.comment
      },
      { onConflict: 'id' }
    );
    if (error) {
      console.error(`  Error inserting review #${r.id}:`, error.message);
    }
  }

  // 6. Create Evaluator Accounts in Supabase Auth
  const evaluatorPassword = process.env.EVALUATOR_PASSWORD || 'Evaluator2026!';
  let evaluatorsCount = 0;

  console.log('  Setting up evaluator test accounts in Supabase Auth...');
  for (const evalUser of seed.evaluators) {
    try {
      // Create or update in Supabase Auth via admin API
      const { data: authUser, error: authErr } = await client.auth.admin.createUser({
        email: evalUser.email,
        password: evaluatorPassword,
        email_confirm: true,
        user_metadata: {
          name: evalUser.name,
          major: evalUser.major,
          semester: evalUser.semester,
          bio: evalUser.bio,
          skills: evalUser.skills,
          evaluator_role: evalUser.role
        }
      });

      let authUserId: string | null = null;
      if (authUser?.user) {
        authUserId = authUser.user.id;
        evaluatorsCount++;
      } else if (authErr?.message.includes('already registered')) {
        // Find existing user id
        const { data: usersList } = await client.auth.admin.listUsers();
        const existing = usersList?.users?.find((u) => u.email === evalUser.email);
        if (existing) {
          authUserId = existing.id;
          evaluatorsCount++;
          // Ensure password is updated to evaluatorPassword
          await client.auth.admin.updateUserById(existing.id, {
            password: evaluatorPassword
          });
        }
      }

      // Ensure profile exists in users table linked to this auth_user_id
      if (authUserId) {
        const { data: existingProfile } = await client
          .from('users')
          .select('id')
          .eq('email', evalUser.email)
          .maybeSingle();

        if (existingProfile) {
          await client
            .from('users')
            .update({ auth_user_id: authUserId })
            .eq('id', existingProfile.id);
        } else {
          await client.from('users').insert({
            auth_user_id: authUserId,
            email: evalUser.email,
            name: evalUser.name,
            major: evalUser.major,
            semester: evalUser.semester,
            bio: evalUser.bio,
            skills: evalUser.skills
          });
        }
      }
    } catch (err: any) {
      console.warn(`  Evaluator ${evalUser.email} setup notice:`, err.message);
    }
  }

  console.log('✅ Supabase database seed completed successfully!');
  console.log(`   - Student Profiles: ${seed.users.length}`);
  console.log(`   - Marketplace Gigs: ${seed.gigs.length}`);
  console.log(`   - Applications: ${seed.applications.length}`);
  console.log(`   - Peer Reviews: ${seed.reviews.length}`);
  console.log(`   - Evaluator Accounts: ${evaluatorsCount}`);

  return {
    usersCount: seed.users.length,
    gigsCount: seed.gigs.length,
    appsCount: seed.applications.length,
    reviewsCount: seed.reviews.length,
    evaluatorsCount
  };
}

async function main() {
  try {
    await runSupabaseSeed();
    process.exit(0);
  } catch (err: any) {
    console.error('❌ Seeding failed:', err.message);
    process.exit(1);
  }
}

if (import.meta.url.endsWith(process.argv[1]) || process.argv[1]?.includes('seed.ts')) {
  main();
}
