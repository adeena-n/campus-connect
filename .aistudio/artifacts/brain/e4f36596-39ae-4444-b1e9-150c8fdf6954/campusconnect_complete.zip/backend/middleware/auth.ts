import { Request, Response, NextFunction } from 'express';
import { supabase, isSupabaseServerConfigured } from '../supabase.ts';
import { supabaseDb } from '../services/supabaseDb.ts';
import { localEngine } from '../services/localEngine.ts';
import { User } from '../types.ts';

declare global {
  namespace Express {
    interface Request {
      authUser?: User;
      authUserId?: number;
      supabaseAuthUser?: any;
    }
  }
}

export function extractBearerToken(authHeader?: string | null): string | null {
  if (!authHeader) return null;
  const parts = authHeader.trim().split(' ');
  if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer') {
    return null;
  }
  return parts[1].trim();
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.header('Authorization');
  const token = extractBearerToken(authHeader);

  if (!token) {
    return res.status(401).json({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: 'Authentication required. Please sign in with your student account.'
      }
    });
  }

  try {
    if (isSupabaseServerConfigured()) {
      const client = supabase.client;
      const { data: { user }, error } = await client.auth.getUser(token);

      if (error || !user) {
        return res.status(401).json({
          success: false,
          error: {
            code: 'INVALID_TOKEN',
            message: error?.message || 'Invalid or expired student session. Please sign in again.'
          }
        });
      }

      const studentProfile = await supabaseDb.linkOrRegisterAuthProfile(user);
      req.supabaseAuthUser = user;
      req.authUser = studentProfile;
      req.authUserId = studentProfile.id;
      return next();
    }

    // Local Preview Engine verification
    const verified = localEngine.verifySessionToken(token);
    if (!verified) {
      return res.status(401).json({
        success: false,
        error: {
          code: 'INVALID_TOKEN',
          message: 'Invalid or expired session. Please sign in again.'
        }
      });
    }

    const studentProfile = await localEngine.getUserById(verified.userId);
    if (!studentProfile) {
      return res.status(401).json({
        success: false,
        error: { code: 'USER_NOT_FOUND', message: 'Student profile not found.' }
      });
    }

    req.authUser = studentProfile;
    req.authUserId = studentProfile.id;
    next();
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: {
        code: 'AUTH_VERIFICATION_FAILED',
        message: err.message || 'Failed to verify authenticated session.'
      }
    });
  }
}

export async function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const authHeader = req.header('Authorization');
  const token = extractBearerToken(authHeader);

  if (!token) {
    return next();
  }

  try {
    if (isSupabaseServerConfigured()) {
      const client = supabase.client;
      const { data: { user } } = await client.auth.getUser(token);
      if (user) {
        const studentProfile = await supabaseDb.linkOrRegisterAuthProfile(user);
        req.supabaseAuthUser = user;
        req.authUser = studentProfile;
        req.authUserId = studentProfile.id;
      }
    } else {
      const verified = localEngine.verifySessionToken(token);
      if (verified) {
        const studentProfile = await localEngine.getUserById(verified.userId);
        if (studentProfile) {
          req.authUser = studentProfile;
          req.authUserId = studentProfile.id;
        }
      }
    }
  } catch {
    // optional auth ignore
  }

  next();
}
