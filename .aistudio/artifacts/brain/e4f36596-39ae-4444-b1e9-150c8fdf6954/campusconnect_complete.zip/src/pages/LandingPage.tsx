import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../services/api.ts';
import { Gig } from '../types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Code2,
  Palette,
  PenTool,
  GraduationCap,
  ArrowRight,
  Search,
  CheckCircle2,
  Clock,
  ChevronRight,
  DollarSign,
  Repeat,
  HeartHandshake
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [featuredGigs, setFeaturedGigs] = useState<Gig[]>([]);
  const [loading, setLoading] = useState(true);
  const [heroSearchQuery, setHeroSearchQuery] = useState('');

  useEffect(() => {
    let active = true;
    const fetchFeatured = async () => {
      try {
        const gigs = await api.getGigs({ status: 'Open' });
        if (active) {
          setFeaturedGigs(gigs.slice(0, 6));
        }
      } catch (err) {
        console.error('Failed to load featured gigs:', err);
      } finally {
        if (active) setLoading(false);
      }
    };

    fetchFeatured();
    return () => {
      active = false;
    };
  }, []);

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearchQuery.trim()) {
      navigate(`/explore?q=${encodeURIComponent(heroSearchQuery.trim())}`);
    } else {
      navigate('/explore');
    }
  };

  const categories = [
    {
      name: 'Programming',
      icon: Code2,
      description: 'Web development, Python scripts, algorithms, mobile apps, and debugging.',
      query: 'Programming'
    },
    {
      name: 'Design',
      icon: Palette,
      description: 'Figma prototypes, club logos, slide deck aesthetics, and vector illustrations.',
      query: 'Design'
    },
    {
      name: 'Writing',
      icon: PenTool,
      description: 'Research paper editing, statement of purpose polish, and literature reviews.',
      query: 'Writing'
    },
    {
      name: 'Tutoring',
      icon: GraduationCap,
      description: 'Peer coaching in calculus, organic chemistry, linear algebra, and data science.',
      query: 'Tutoring'
    }
  ];

  return (
    <div className="space-y-20 pb-20">
      {/* Editorial Hero Section */}
      <section className="pt-6 sm:pt-12 pb-10 border-b border-[#E7E8E1]">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="text-xs font-medium text-[#18392B] uppercase tracking-wider">
            The University Freelance & Skill Exchange
          </div>

          <h1 className="text-4xl sm:text-6xl font-serif font-normal tracking-tight text-[#202820] leading-[1.12] text-balance">
            Where campus talent meets <span className="italic font-serif text-[#18392B]">campus need.</span>
          </h1>

          <p className="text-base sm:text-lg text-[#72766F] max-w-2xl mx-auto leading-relaxed">
            CampusConnect connects university students to exchange programming, design, and tutoring services, collaborate on coursework, and build verified reputation.
          </p>

          {/* Direct Marketplace Search in Hero */}
          <form onSubmit={handleHeroSearch} className="max-w-xl mx-auto pt-2">
            <div className="flex items-center gap-2 p-1.5 bg-white rounded-xl border border-[#E7E8E1] shadow-xs focus-within:border-[#18392B] transition">
              <Search className="w-4 h-4 ml-3 text-[#72766F] shrink-0" />
              <input
                type="text"
                value={heroSearchQuery}
                onChange={(e) => setHeroSearchQuery(e.target.value)}
                placeholder="Search gigs by skill, coursework, or topic (e.g. Python, Figma, Calculus)..."
                className="w-full px-2 py-2 text-xs sm:text-sm bg-transparent text-[#202820] placeholder-[#72766F]/60 focus:outline-none"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-[#18392B] hover:bg-[#23523E] text-[#FAF9F6] text-xs font-medium rounded-lg transition whitespace-nowrap shrink-0 cursor-pointer"
              >
                Find Gigs
              </button>
            </div>
          </form>

          {/* Quick CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <Link
              to="/explore"
              className="px-5 py-2.5 bg-[#FAF9F6] hover:bg-[#EBF0E8] text-[#202820] text-xs font-medium rounded-lg border border-[#E7E8E1] transition flex items-center gap-1.5"
            >
              <span>Explore Gigs</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#72766F]" />
            </Link>

            <Link
              to="/talent"
              className="px-5 py-2.5 bg-[#FAF9F6] hover:bg-[#EBF0E8] text-[#202820] text-xs font-medium rounded-lg border border-[#E7E8E1] transition flex items-center gap-1.5"
            >
              <span>Discover Talent</span>
            </Link>

            {isAuthenticated ? (
              <Link
                to="/create"
                className="px-5 py-2.5 bg-[#18392B] hover:bg-[#23523E] text-[#FAF9F6] text-xs font-medium rounded-lg transition shadow-xs"
              >
                + Post a Gig
              </Link>
            ) : (
              <Link
                to="/signup"
                className="px-5 py-2.5 bg-[#18392B] hover:bg-[#23523E] text-[#FAF9F6] text-xs font-medium rounded-lg transition shadow-xs"
              >
                Create Student Account
              </Link>
            )}
          </div>
        </div>

        {/* Hero Visual Asset */}
        <div className="max-w-5xl mx-auto mt-10">
          <div className="relative rounded-2xl overflow-hidden border border-[#E7E8E1] bg-white shadow-xs">
            <img
              src="/src/assets/images/campus_collaboration_hero_1792564680854.jpg"
              alt="University students collaborating over coursework and laptops in a campus study hall"
              referrerPolicy="no-referrer"
              className="w-full h-[320px] sm:h-[440px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-6">
              <div className="text-[#FAF9F6] text-xs sm:text-sm font-medium">
                Academic collaboration hub · Verified peer-to-peer exchange for campus students
              </div>
            </div>
          </div>
        </div>

        {/* Quantitative Proof Strip */}
        <div className="pt-10 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-4xl mx-auto text-left">
          <div className="border-l border-[#E7E8E1] pl-4">
            <div className="text-2xl font-serif text-[#202820] tabular-nums">100%</div>
            <div className="text-xs text-[#72766F] mt-0.5">Verified Student Peers</div>
          </div>
          <div className="border-l border-[#E7E8E1] pl-4">
            <div className="text-2xl font-serif text-[#202820]">3 Models</div>
            <div className="text-xs text-[#72766F] mt-0.5">Paid, SkillSwap & Free</div>
          </div>
          <div className="border-l border-[#E7E8E1] pl-4">
            <div className="text-2xl font-serif text-[#202820]">Two-Way</div>
            <div className="text-xs text-[#72766F] mt-0.5">Mutual Portfolio Reviews</div>
          </div>
          <div className="border-l border-[#E7E8E1] pl-4">
            <div className="text-2xl font-serif text-[#202820] tabular-nums">0%</div>
            <div className="text-xs text-[#72766F] mt-0.5">Platform Service Fees</div>
          </div>
        </div>
      </section>

      {/* Two Sides of Campus: Offering vs. Requesting */}
      <section className="max-w-5xl mx-auto space-y-8">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-xs font-medium uppercase tracking-wider text-[#72766F]">
            Single Flexible Student Role
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif text-[#202820]">
            Offer your strengths. Request help where you need it.
          </h2>
          <p className="text-xs sm:text-sm text-[#72766F]">
            Every registered student account can seamlessly post service offerings, request project assistance, and apply to peers across departments.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          {/* Card 1: Offering */}
          <div className="rounded-xl bg-white border border-[#E7E8E1] overflow-hidden flex flex-col justify-between shadow-xs">
            <img
              src="/src/assets/images/student_creative_design_1792564680138.jpg"
              alt="University student designing user interfaces and digital wireframes in campus studio"
              referrerPolicy="no-referrer"
              className="w-full h-56 object-cover"
            />
            <div className="p-6 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-xs font-semibold text-[#18392B] uppercase tracking-wider">
                  Student Creators
                </span>
                <h3 className="text-xl font-serif text-[#202820] mt-1">Offering Gigs</h3>
                <p className="text-xs text-[#72766F] mt-2 leading-relaxed">
                  Have experience in web development, Figma design, statistical analysis, or chemistry? Post your offerings to tutor classmates, build apps for campus clubs, and build a verified portfolio.
                </p>
              </div>

              <div className="pt-4 border-t border-[#E7E8E1] space-y-2 text-xs text-[#202820]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#18392B] shrink-0" />
                  <span>Set fixed budgets or propose 1:1 SkillSwaps</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#18392B] shrink-0" />
                  <span>Receive direct proposals from student applicants</span>
                </div>
              </div>
            </div>
          </div>

          {/* Card 2: Requesting */}
          <div className="rounded-xl bg-white border border-[#E7E8E1] overflow-hidden flex flex-col justify-between shadow-xs">
            <img
              src="/src/assets/images/student_peer_tutoring_1792564680934.jpg"
              alt="Two university students studying code and calculus notes in library"
              referrerPolicy="no-referrer"
              className="w-full h-56 object-cover"
            />
            <div className="p-6 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-xs font-semibold text-[#C77755] uppercase tracking-wider">
                  Student Collaborators
                </span>
                <h3 className="text-xl font-serif text-[#202820] mt-1">Requesting Assistance</h3>
                <p className="text-xs text-[#72766F] mt-2 leading-relaxed">
                  Stuck on a tricky linear algebra assignment, preparing a pitch deck for a startup challenge, or needing a custom website? Post a request and connect directly with talented student peers.
                </p>
              </div>

              <div className="pt-4 border-t border-[#E7E8E1] space-y-2 text-xs text-[#202820]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#C77755] shrink-0" />
                  <span>Select the most qualified peer and review their reputation</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#C77755] shrink-0" />
                  <span>Controlled workflow from In Progress to mutual review</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Disciplines Grid */}
      <section className="max-w-5xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <span className="text-xs font-medium uppercase tracking-wider text-[#72766F]">
              Browse Disciplines
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif text-[#202820] mt-1">
              Explore Campus Departments
            </h2>
          </div>
          <Link
            to="/explore"
            className="text-xs font-medium text-[#18392B] hover:underline flex items-center gap-1"
          >
            <span>View all marketplace listings</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <Link
                key={cat.name}
                to={`/explore?category=${cat.query}`}
                className="p-6 bg-white rounded-xl border border-[#E7E8E1] hover:border-[#18392B] transition group flex flex-col justify-between shadow-xs"
              >
                <div>
                  <div className="w-10 h-10 rounded-lg bg-[#FAF9F6] border border-[#E7E8E1] text-[#18392B] flex items-center justify-center mb-4 group-hover:bg-[#EBF0E8] transition">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-serif text-lg text-[#202820] group-hover:text-[#18392B] transition">
                    {cat.name}
                  </h3>
                  <p className="text-xs text-[#72766F] mt-2 leading-relaxed">
                    {cat.description}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#E7E8E1] text-xs font-medium text-[#18392B] flex items-center gap-1">
                  <span>Browse {cat.name}</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Featured Gigs Grid */}
      <section className="max-w-5xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <span className="text-xs font-medium uppercase tracking-wider text-[#72766F]">
              Live Opportunities
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif text-[#202820] mt-1">
              Recent Marketplace Listings
            </h2>
          </div>
          <Link
            to="/explore"
            className="text-xs font-medium text-[#18392B] hover:underline flex items-center gap-1"
          >
            <span>Browse all open gigs</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-52 bg-white rounded-xl border border-[#E7E8E1] animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {featuredGigs.map((gig) => (
              <Link
                key={gig.id}
                to={`/gigs/${gig.id}`}
                className="p-5 bg-white rounded-xl border border-[#E7E8E1] hover:border-[#18392B] transition flex flex-col justify-between group shadow-xs"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs text-[#72766F]">
                    <span className="text-[#18392B] font-medium">
                      {gig.category}
                    </span>
                    <span>{gig.type}</span>
                  </div>

                  <h3 className="font-serif text-base text-[#202820] group-hover:text-[#18392B] transition line-clamp-2">
                    {gig.title}
                  </h3>

                  <p className="text-xs text-[#72766F] line-clamp-2 leading-relaxed">
                    {gig.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#E7E8E1] flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#18392B] tabular-nums">
                    {gig.payment_type === 'Paid'
                      ? `$${gig.budget?.toLocaleString()}`
                      : gig.payment_type}
                  </span>
                  <span className="text-[#72766F] text-xs flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#A8B8A0]" />
                    {new Date(gig.deadline).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* The Three Payment Models Explained */}
      <section className="max-w-5xl mx-auto p-8 sm:p-12 bg-white rounded-xl border border-[#E7E8E1] space-y-8 shadow-xs">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-medium uppercase tracking-wider text-[#72766F]">
            Transparent Compensation
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif text-[#202820]">
            Three flexible ways to collaborate
          </h2>
          <p className="text-xs sm:text-sm text-[#72766F]">
            CampusConnect supports university student budgets through three fair and transparent collaboration types.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
          <div className="space-y-3 p-5 rounded-lg bg-[#FAF9F6] border border-[#E7E8E1]">
            <div className="w-8 h-8 rounded-md bg-[#EBF0E8] text-[#18392B] flex items-center justify-center font-bold text-sm">
              <DollarSign className="w-4 h-4" />
            </div>
            <h4 className="font-serif text-base text-[#202820]">Paid Gigs</h4>
            <p className="text-xs text-[#72766F] leading-relaxed">
              Clear upfront monetary compensation agreed between students for high-effort projects, development sprints, and formal tutoring.
            </p>
          </div>

          <div className="space-y-3 p-5 rounded-lg bg-[#FAF9F6] border border-[#E7E8E1]">
            <div className="w-8 h-8 rounded-md bg-[#FAF2EE] text-[#C77755] flex items-center justify-center font-bold text-sm">
              <Repeat className="w-4 h-4" />
            </div>
            <h4 className="font-serif text-base text-[#202820]">SkillSwap</h4>
            <p className="text-xs text-[#72766F] leading-relaxed">
              Direct exchange of skills without money: barter a custom Figma logo for API backend debugging, or essay editing for calculus coaching.
            </p>
          </div>

          <div className="space-y-3 p-5 rounded-lg bg-[#FAF9F6] border border-[#E7E8E1]">
            <div className="w-8 h-8 rounded-md bg-[#EBF0E8] text-[#72766F] flex items-center justify-center font-bold text-sm">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <h4 className="font-serif text-base text-[#202820]">Free Peer Support</h4>
            <p className="text-xs text-[#72766F] leading-relaxed">
              Voluntary mentorship, quick resume reviews, exam study sessions, and student club initiatives with zero financial barrier.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="max-w-5xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-medium uppercase tracking-wider text-[#72766F]">
            Structured Lifecycle
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif text-[#202820]">
            How CampusConnect works
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-xl border border-[#E7E8E1] space-y-3 shadow-xs">
            <span className="text-xs font-serif italic text-[#72766F]">01</span>
            <h4 className="font-serif text-lg text-[#202820]">Post or Discover</h4>
            <p className="text-xs text-[#72766F] leading-relaxed">
              Publish a validated gig with category, deadline, and compensation type, or search marketplace listings using combined filters.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-[#E7E8E1] space-y-3 shadow-xs">
            <span className="text-xs font-serif italic text-[#72766F]">02</span>
            <h4 className="font-serif text-lg text-[#202820]">Select & Collaborate</h4>
            <p className="text-xs text-[#72766F] leading-relaxed">
              Review applicant proposals and credentials. Selecting a student transitions the gig to In Progress and locks other applications.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-[#E7E8E1] space-y-3 shadow-xs">
            <span className="text-xs font-serif italic text-[#72766F]">03</span>
            <h4 className="font-serif text-lg text-[#202820]">Review & Build Reputation</h4>
            <p className="text-xs text-[#72766F] leading-relaxed">
              Upon completion, both students leave mutual 1–5 star reviews and feedback, permanently strengthening academic portfolio ratings.
            </p>
          </div>
        </div>
      </section>

      {/* Editorial Call to Action */}
      <section className="max-w-5xl mx-auto p-10 sm:p-14 bg-[#18392B] rounded-2xl text-[#FAF9F6] text-center space-y-5 shadow-sm">
        <span className="text-xs font-medium tracking-wider uppercase text-[#A8B8A0]">
          University Student Community
        </span>
        <h2 className="text-3xl sm:text-5xl font-serif font-normal tracking-tight max-w-xl mx-auto leading-tight text-balance">
          Ready to put your skills to work on campus?
        </h2>
        <p className="text-sm text-[#FAF9F6]/80 max-w-md mx-auto leading-relaxed">
          Create your verified student profile today and connect with peers across engineering, design, humanities, and sciences.
        </p>
        <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
          <Link
            to="/signup"
            className="px-6 py-3 bg-[#FAF9F6] hover:bg-white text-[#18392B] text-xs font-medium rounded-lg transition shadow-xs"
          >
            Get Started Free
          </Link>
          <Link
            to="/explore"
            className="px-6 py-3 bg-transparent hover:bg-white/10 text-[#FAF9F6] text-xs font-medium rounded-lg border border-[#A8B8A0]/40 transition"
          >
            Browse Marketplace
          </Link>
        </div>
      </section>
    </div>
  );
};
