import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User } from '../types.ts';
import { api, getStoredAuthToken, clearStoredAuthToken, setStoredAuthToken } from '../services/api.ts';
import { supabase, isSupabaseConfigured } from '../services/supabase.ts';

export interface ToastItem {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  message?: string;
}

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  login: (credentials: { email: string; password: string }) => Promise<void>;
  signup: (data: {
    email: string;
    password: string;
    name: string;
    major: string;
    semester: number;
    bio?: string;
    skills?: string[];
  }) => Promise<void>;
  logout: () => Promise<void>;
  refreshCurrentUser: () => Promise<void>;
  toasts: ToastItem[];
  addToast: (title: string, message?: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const addToast = useCallback((title: string, message?: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Fetch current user from active session token
  const refreshCurrentUser = useCallback(async () => {
    const token = getStoredAuthToken();
    if (!token) {
      setCurrentUser(null);
      return;
    }
    try {
      const user = await api.getMe();
      setCurrentUser(user);
    } catch {
      clearStoredAuthToken();
      setCurrentUser(null);
    }
  }, []);

  // Login handler
  const login = useCallback(
    async (credentials: { email: string; password: string }) => {
      // 1. Direct Supabase Auth client if configured
      if (isSupabaseConfigured && supabase) {
        const { data: supaData, error: supaErr } = await supabase.auth.signInWithPassword({
          email: credentials.email.trim().toLowerCase(),
          password: credentials.password
        });

        if (supaErr) {
          throw new Error(supaErr.message);
        }

        if (supaData.session?.access_token) {
          setStoredAuthToken(supaData.session.access_token);
        }
      }

      // 2. Fetch authenticated profile from backend
      try {
        const { user, token } = await api.login(credentials);
        if (token) setStoredAuthToken(token);
        setCurrentUser(user);
        addToast('Welcome back', `Signed in as ${user.name}`, 'success');
      } catch (err: any) {
        // If login endpoint threw, verify if we already got user via getMe
        if (getStoredAuthToken()) {
          const user = await api.getMe();
          setCurrentUser(user);
          addToast('Welcome back', `Signed in as ${user.name}`, 'success');
          return;
        }
        throw err;
      }
    },
    [addToast]
  );

  // Signup handler
  const signup = useCallback(
    async (data: {
      email: string;
      password: string;
      name: string;
      major: string;
      semester: number;
      bio?: string;
      skills?: string[];
    }) => {
      if (isSupabaseConfigured && supabase) {
        const { data: supaData, error: supaErr } = await supabase.auth.signUp({
          email: data.email.trim().toLowerCase(),
          password: data.password,
          options: {
            data: {
              name: data.name.trim(),
              major: data.major.trim(),
              semester: Number(data.semester),
              bio: data.bio?.trim() || '',
              skills: data.skills || []
            }
          }
        });

        if (supaErr) {
          throw new Error(supaErr.message);
        }

        if (supaData.session?.access_token) {
          setStoredAuthToken(supaData.session.access_token);
        }
      }

      const res = await api.signup(data);
      if (res.token) setStoredAuthToken(res.token);
      setCurrentUser(res.user);
      addToast('Profile Created', `Welcome to CampusConnect, ${res.user.name}!`, 'success');
    },
    [addToast]
  );

  // Logout handler
  const logout = useCallback(async () => {
    if (isSupabaseConfigured && supabase) {
      try {
        await supabase.auth.signOut();
      } catch {
        // ignore
      }
    }
    await api.logout();
    setCurrentUser(null);
    addToast('Signed Out', 'You have safely signed out of your student session.', 'info');
  }, [addToast]);

  useEffect(() => {
    let mounted = true;

    const initAuth = async () => {
      setLoading(true);

      // Listen for Supabase session changes
      if (isSupabaseConfigured && supabase) {
        try {
          const { data } = await supabase.auth.getSession();
          if (data.session?.access_token) {
            setStoredAuthToken(data.session.access_token);
          }
        } catch (e) {
          console.warn('Supabase getSession notice:', e);
        }

        // Set up listener
        const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
          if (session?.access_token) {
            setStoredAuthToken(session.access_token);
            refreshCurrentUser();
          } else {
            clearStoredAuthToken();
            setCurrentUser(null);
          }
        });

        await refreshCurrentUser();
        if (mounted) setLoading(false);

        return () => {
          authListener?.subscription.unsubscribe();
        };
      }

      await refreshCurrentUser();
      if (mounted) setLoading(false);
    };

    initAuth();
    return () => {
      mounted = false;
    };
  }, [refreshCurrentUser]);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: Boolean(currentUser),
        loading,
        login,
        signup,
        logout,
        refreshCurrentUser,
        toasts,
        addToast,
        removeToast
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Compatibility aliases
export const useDemoUser = useAuth;
export const DemoUserProvider = AuthProvider;
