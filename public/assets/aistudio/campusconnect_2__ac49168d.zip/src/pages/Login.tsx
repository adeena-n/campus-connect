import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.tsx';
import { ArrowRight, AlertCircle, GraduationCap } from 'lucide-react';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const from = (location.state as any)?.from?.pathname || '/dashboard';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please enter both email and password.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await login({ email: email.trim(), password });
      navigate(from, { replace: true });
    } catch (err: any) {
      setError(err.message || 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickSelect = (studentEmail: string) => {
    setEmail(studentEmail);
    setPassword('password123');
    setError(null);
  };

  return (
    <div className="min-h-[75vh] flex items-center justify-center py-12 px-4 sm:px-6">
      <div className="max-w-md w-full space-y-8 bg-white p-8 sm:p-10 rounded-2xl border border-[#E7E8E1] shadow-xs">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-10 h-10 rounded-xl bg-[#18392B] text-[#FAF9F6] flex items-center justify-center mx-auto mb-2 shadow-xs">
            <GraduationCap className="w-5 h-5 text-[#A8B8A0]" />
          </div>
          <h1 className="text-3xl font-serif font-normal tracking-tight text-[#202820]">
            Sign in to CampusConnect
          </h1>
          <p className="text-xs sm:text-sm text-[#72766F]">
            Access your campus gigs, proposals, and peer student network.
          </p>
        </div>

        {/* Error notification */}
        {error && (
          <div className="p-3.5 bg-[#FAF2EE] border border-[#F0D5C9] rounded-lg text-xs text-[#C77755] flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-[#C77755] shrink-0 mt-0.5" />
            <div className="font-medium">{error}</div>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#202820] mb-1.5">
              University Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. sara.ahmed@campus.edu"
              required
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-[#E7E8E1] bg-white text-[#202820] placeholder-[#72766F]/60 focus:outline-none focus:border-[#18392B] transition"
              disabled={loading}
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-medium text-[#202820]">
                Password
              </label>
              <span className="text-[11px] text-[#72766F]">Min 6 characters</span>
            </div>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-[#E7E8E1] bg-white text-[#202820] placeholder-[#72766F]/60 focus:outline-none focus:border-[#18392B] transition"
              disabled={loading}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-2.5 px-4 bg-[#18392B] hover:bg-[#23523E] text-[#FAF9F6] text-xs sm:text-sm font-medium rounded-lg transition flex items-center justify-center gap-2 disabled:opacity-60 shadow-xs cursor-pointer"
          >
            <span>{loading ? 'Signing in...' : 'Sign In'}</span>
            {!loading && <ArrowRight className="w-4 h-4 text-[#A8B8A0]" />}
          </button>
        </form>

        {/* Quiet Quick Student Credentials for evaluation */}
        <div className="pt-4 border-t border-[#E7E8E1] text-xs text-[#72766F] space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-medium text-[#202820]">Quick sign-in for testing:</span>
            <span className="font-mono text-[#72766F]">password123</span>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={() => handleQuickSelect('sara.ahmed@campus.edu')}
              className="text-left px-2.5 py-1.5 rounded-lg border border-[#E7E8E1] hover:bg-[#FAF9F6] text-[11px] text-[#202820] truncate cursor-pointer"
            >
              Sara Ahmed (CS)
            </button>
            <button
              type="button"
              onClick={() => handleQuickSelect('ali.khan@campus.edu')}
              className="text-left px-2.5 py-1.5 rounded-lg border border-[#E7E8E1] hover:bg-[#FAF9F6] text-[11px] text-[#202820] truncate cursor-pointer"
            >
              Ali Khan (SE)
            </button>
            <button
              type="button"
              onClick={() => handleQuickSelect('maya.chen@campus.edu')}
              className="text-left px-2.5 py-1.5 rounded-lg border border-[#E7E8E1] hover:bg-[#FAF9F6] text-[11px] text-[#202820] truncate cursor-pointer"
            >
              Maya Chen (Design)
            </button>
            <button
              type="button"
              onClick={() => handleQuickSelect('liam.oconnor@campus.edu')}
              className="text-left px-2.5 py-1.5 rounded-lg border border-[#E7E8E1] hover:bg-[#FAF9F6] text-[11px] text-[#202820] truncate cursor-pointer"
            >
              Liam O'Connor (Lit)
            </button>
          </div>
        </div>

        {/* Link to Sign Up */}
        <div className="pt-1 text-center text-xs text-[#72766F]">
          <span>New to CampusConnect? </span>
          <Link to="/signup" className="font-semibold text-[#18392B] hover:underline">
            Create student profile
          </Link>
        </div>
      </div>
    </div>
  );
};
