# CampusConnect — University Student Freelance & Skill-Exchange Marketplace

CampusConnect is a production-style campus marketplace for university students to exchange short-term services, offer peer tutoring, collaborate on technical projects, and build verifiable academic reputation.

---

## 🛠️ Technology Stack

- **Frontend**: React 19, Vite, Tailwind CSS v4, React Router v7, Lucide Icons
- **Design System**: Modern editorial marketplace (Deep forest green `#18392B`, Muted sage `#A8B8A0`, Warm ivory `#FAF9F6`, Charcoal text `#202820`, Terracotta `#C77755`)
- **Typography**: Newsreader (editorial serif headings) + DM Sans (body)
- **Backend**: Node.js, Express, TypeScript (executed via `tsx`)
- **Authentication**: Supabase Auth client integration with bearer token sessions and persistent student accounts
- **Persistence**: Atomic, synchronized persistent JSON mock store (`backend/data/db.json`)
- **Communication**: REST API via Fetch API with unified response envelopes (`{ success: true, data: ... }`)

---

## 🚀 Quickstart & Commands

### 1. Installation
```bash
npm install
```

### 2. Configure Supabase (Optional)
To connect live Supabase Authentication and database, set these variables in your environment:
```env
VITE_SUPABASE_URL="https://your-project.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-public-key"
SUPABASE_SERVICE_ROLE_KEY="your-service-role-key" # Server-side only
```
*Note: If unconfigured, CampusConnect operates seamlessly in local authenticated mode with the same production session interfaces.*

### 3. Reset / Seed Database
Initializes or resets the mock database with all required seed records:
- **12** unique student profiles across multiple university departments
- **25** gigs (8 Programming, 6 Design, 6 Writing, 5 Tutoring; 12 Open, 5 In Progress, 5 Completed, 2 Expired, 1 Cancelled)
- **25** student applications
- **10** mutual peer reviews with verified participant authorization
```bash
npm run seed
```

### 4. Start Development Server
Starts the full-stack server running Express with Vite dev middleware on port 3000:
```bash
npm run dev
```
Open **http://localhost:3000** in your browser.

### 5. Build for Production
```bash
npm run build
npm start
```

---

## 🔐 Student Accounts for Testing

All seeded student accounts can be accessed using their campus email and the password `password123`:
- **Sara Ahmed**: `sara.ahmed@campus.edu` (Computer Science, Semester 3)
- **Ali Khan**: `ali.khan@campus.edu` (Software Engineering, Semester 4)
- **Maya Chen**: `maya.chen@campus.edu` (Graphic Design, Semester 5)
- **Liam O'Connor**: `liam.oconnor@campus.edu` (English Literature, Semester 6)
- **Priya Patel**: `priya.patel@campus.edu` (Mathematics & CS, Semester 2)

New students can also register anytime via the **Sign Up** page (`/signup`).

---

## 🎯 Architecture & Features

1. **Public Landing Page (`/`)**
   - Clean navigation with logo, Explore Gigs, How It Works, Sign In, and Get Started.
   - Editorial hero section highlighting university talent exchange.
   - Dual breakdown of Offering vs. Requesting gigs.
   - Live featured gigs retrieved dynamically from the API.
   - Department category explorer (Programming, Design, Writing, Tutoring).
   - Clear explanation of Paid, SkillSwap, and Free arrangements.

2. **Authentication & Student Sessions**
   - Supabase client integration with JWT session parsing on the backend (`Authorization: Bearer <token>`).
   - Sign in (`/login`) and Sign up (`/signup`) with profile onboarding (name, major, semester, bio, and skills).
   - Protected student workspace routes (`/dashboard`, `/create`, `/my-gigs`, `/my-applications`).

3. **Explore Gigs (`/explore`)**
   - Professional freelance marketplace listing design.
   - Keyword search across titles and descriptions.
   - Multi-facet filters combining category, type, payment model, status, and budget range.
   - Dynamic auto-expiry on the server for deadlines that have passed.

4. **Applicant Management & Atomic Workflow (FR-05)**
   - When an owner accepts an applicant:
     - Selected application transitions to `Accepted`.
     - Other pending applications are automatically marked `Rejected`.
     - `gig.accepted_applicant_id` references the accepted application ID.
     - Gig status transitions to `In Progress` and blocks further submissions.

5. **Mutual Reviews & Reputation (FR-07)**
   - Only authorized participants of completed gigs can review each other.
   - Mutual 1–5 star ratings with required feedback dynamically update profile averages.

---

## 🛡️ Acceptance Test Matrix

Run the automated 24-test acceptance suite anytime:
```bash
npx tsx backend/verifyMatrix.ts
```
All 24 test matrix scenarios pass cleanly with 100% compliance.
